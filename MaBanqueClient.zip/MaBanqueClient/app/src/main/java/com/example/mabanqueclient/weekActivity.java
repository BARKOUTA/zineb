package com.example.mabanqueclient;

public class weekActivity {
}
