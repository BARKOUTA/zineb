package com.example.mabanqueclient;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Tentative;
    private Button   Login;
    private int conteur = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Name = (EditText)findViewById(R.id.IdName);
        Password=(EditText)findViewById(R.id.IDpass);
        Tentative=(TextView) findViewById(R.id.IdTentative);
        Login=(Button)findViewById(R.id.IdBouton);

        Login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                Validate(Name.getText().toString(), Password.getText().toString());
            }
        });
    }

    private void Validate(String userName, String userPassword){
        if((userName.equals("Admin")) && (userPassword.equals("1234"))){
            Intent intent= new Intent(MainActivity.this, Moncompte.class);
            startActivity(intent);
        }else{
            conteur--;
            Tentative.setText("nombre de tentatives restantes" +conteur);
            if(conteur == 0){
                Login.setEnabled(false);

            }
        }
    }
}
